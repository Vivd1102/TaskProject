//
//  Constant.swift
//

import Foundation

enum Config {
    // Copy base url here
    static let baseUrl = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"
}

